package com.capgemini.mobilepurchase.exceptions;

public class MobilePurchaseException extends Exception {
	
	public MobilePurchaseException(String msg)
	{
		super(msg);
	}

}
