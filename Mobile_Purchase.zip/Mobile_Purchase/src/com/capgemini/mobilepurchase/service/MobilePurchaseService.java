package com.capgemini.mobilepurchase.service;

import java.util.ArrayList;

import com.capgemini.mobilepurchase.dto.CustomerDetailsDTO;
import com.capgemini.mobilepurchase.exceptions.MobilePurchaseException;

public interface MobilePurchaseService {
	abstract boolean validateCustomerName(String cName);
	abstract boolean validateMailId(String cMail);
	abstract boolean validatePhoneNumber(String cPhn);
	abstract boolean validateMobileId(String cMobile);
	//abstract boolean validatePurchaseId(String cPID);
	abstract boolean validatePurchaseDate(String cPDate);
	abstract public CustomerDetailsDTO mobilepur(CustomerDetailsDTO cdto)throws MobilePurchaseException;
	public int getpid() throws MobilePurchaseException;
	public ArrayList<Integer> getMobId() throws MobilePurchaseException;
	public ArrayList<CustomerDetailsDTO> getAllMobiles() throws MobilePurchaseException;
}