package com.capgemini.mobilepurchase.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.mobilepurchase.dao.MobilePurchaseDao;
import com.capgemini.mobilepurchase.dto.CustomerDetailsDTO;
import com.capgemini.mobilepurchase.exceptions.MobilePurchaseException;

public class MobilePurchaseServiceImp implements MobilePurchaseService {
	
	MobilePurchaseDao dao1;
	public MobilePurchaseServiceImp()
	{
		dao1= new MobilePurchaseDao();
	}
	public CustomerDetailsDTO mobilepur(CustomerDetailsDTO cdto)throws MobilePurchaseException{
		return dao1.mobilepur(cdto);
	}
	public ArrayList<CustomerDetailsDTO> getAllMobiles() throws MobilePurchaseException{
		return dao1.getAllMobiles();
	}
	public boolean validateCustomerName(String cName) {
		String cpattern ="[A-Za-z]{6,10}";
		if(Pattern.matches(cpattern,cName))
		return true;
		return false;
	}

	@Override
	public boolean validateMailId(String cMail) {
		String mpattern ="[a-zA-Z0-9]{1,9}[@][a-zA-Z0-9]{1,9}[.][a-zA-Z0-9]{1,9}";
		if(Pattern.matches(mpattern,cMail))
			return true;
			return false;
	}


	public boolean validatePhoneNumber(String cPhn) {
		String pPattern ="[6-9]{1}[0-9]{9}";
		if(Pattern.matches(pPattern,cPhn))
		return true;
		return false;
	}


	public boolean validateMobileId(String cMobile) {
		String mipattern ="\\d{4}";
		if(Pattern.matches(mipattern,cMobile))
		return true;
		return false;
	}

	
//	public boolean validatePurchaseId(String cPID) {
//		String pipattern = "\\d{4}";
//		if(Pattern.matches(pipattern,cPID))
//		return true;
//		return false;
//	}

	
	public boolean validatePurchaseDate(String cPDate) {
		
		return false;
	}
	MobilePurchaseDao dao;
	
	
	public int getpid() throws MobilePurchaseException {
		dao1= new MobilePurchaseDao();
		return dao1.getpid();
	}
	
	public ArrayList<Integer> getMobId() throws MobilePurchaseException {
		
		return dao1.getMobId();
	}
	
}
	
	
	
	


