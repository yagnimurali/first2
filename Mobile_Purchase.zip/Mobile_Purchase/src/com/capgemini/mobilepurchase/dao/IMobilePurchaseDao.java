package com.capgemini.mobilepurchase.dao;

import java.util.ArrayList;

import oracle.jdbc.proxy.annotation.GetProxy;

import com.capgemini.mobilepurchase.dto.CustomerDetailsDTO;
import com.capgemini.mobilepurchase.exceptions.MobilePurchaseException;

public interface IMobilePurchaseDao {
	public CustomerDetailsDTO mobilepur(CustomerDetailsDTO cdto)throws MobilePurchaseException;
	public int getpid() throws MobilePurchaseException;
	public ArrayList<Integer> getMobId() throws MobilePurchaseException;

}
