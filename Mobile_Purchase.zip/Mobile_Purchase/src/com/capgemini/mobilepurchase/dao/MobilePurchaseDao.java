package com.capgemini.mobilepurchase.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.mobilepurchase.dto.CustomerDetailsDTO;
import com.capgemini.mobilepurchase.exceptions.MobilePurchaseException;
import com.capgemini.mobilepurchase.util.DBConnection;
//import org.apache.log4j.Logger;

public class MobilePurchaseDao implements IMobilePurchaseDao{
	CustomerDetailsDTO cdto = new CustomerDetailsDTO();
//private Logger logger= Logger.getLogger(IMobilePurchaseDao.class);
	@Override
	public CustomerDetailsDTO mobilepur(CustomerDetailsDTO cdto)
			throws MobilePurchaseException {
		//logger.info("Mobile purchase");
		Connection conn;
		PreparedStatement insertStmt = null;
		try {
			System.out.println("hello");
			java.util.Date udate= cdto.getPurchaseDate();
			java.sql.Date sdate = new java.sql.Date(udate.getTime()); 
			conn = DBConnection.getConnection();
			insertStmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			
			//insertStmt.setInt(1, cdto.getPurchaseId());
			
			insertStmt.setString(1,cdto.getCustomerName());
			insertStmt.setString(2, cdto.getMailId());
			insertStmt.setString(3, cdto.getPhoneNumber());
			
			insertStmt.setDate(4, sdate);
			insertStmt.setInt(5, cdto.getMobileId());
		
			int k = insertStmt.executeUpdate();
			
			{
				if(k==1)
				{
					System.out.println("successfully entered");
					System.out.println("updated");
				}
				else
				{
					System.out.println("not updated");
				}
			}
			
		} catch (Exception e) 
		{
			System.out.println(e+ "not inserted");
		
		}
		
		return cdto;
	}
	public int getpid() throws MobilePurchaseException{
		Connection conn;
		PreparedStatement getpidStmt = null;
		ResultSet regResult = null;
		int pid = 0;
		try {
			conn = DBConnection.getConnection();
			getpidStmt = conn.prepareStatement(IQueryMapper.GET_PID);
			 regResult = getpidStmt.executeQuery();
			 if(regResult.next())
			 {
				 pid = regResult.getInt(1);
				 
			 }
		} catch (MobilePurchaseException | SQLException e) {
			throw new MobilePurchaseException("sorry!! can't process your request now");
			
			}
		return pid;
	}
	
	public ArrayList<Integer> getMobId() throws MobilePurchaseException{
		Connection conn;
		PreparedStatement getpidStmt = null;
		ResultSet regResult = null;
		int mobileId = 0;
		ArrayList<Integer>list=new ArrayList<Integer>();
		try{
			
		conn = DBConnection.getConnection();
		getpidStmt = conn.prepareStatement(IQueryMapper.GET_MobileID);
		regResult=getpidStmt.executeQuery();
		while(regResult.next())
		{
			list.add(regResult.getInt("mobileId"));
		//  logger.info("purchase done!!!purchaseid:"+ pid);
		
		}
		}catch(MobilePurchaseException |SQLException e)
		{
		throw new MobilePurchaseException("sorry!!!Can't process your request now");
		}
		return list;
	}

	public ArrayList<CustomerDetailsDTO> getAllMobiles() throws MobilePurchaseException
	{
	Connection conn;
	ResultSet regResult=null;
	PreparedStatement preparedStatement =null;
	
	ArrayList<CustomerDetailsDTO> customerList=new ArrayList<CustomerDetailsDTO>();
	try{
	conn=DBConnection.getConnection();
	preparedStatement=conn.prepareStatement(IQueryMapper.GET_ALLMOBILES);
	regResult=preparedStatement.executeQuery();
	while(regResult.next())
	{
		CustomerDetailsDTO bean=new CustomerDetailsDTO();
	bean.setMobileId(regResult.getInt(1));
	bean.setMobileName(regResult.getString(2));
	bean.setMobilePrice(regResult.getInt(3));
	bean.setMobileQuantity(regResult.getInt(4));
	customerList.add(bean);
	}
	}
	catch(MobilePurchaseException e)
	{
	throw new MobilePurchaseException("sorry not updated");
	}
	catch(SQLException e)
	{
	throw new MobilePurchaseException("sorry not updated");
	}
	return customerList;
	}
	 

}

