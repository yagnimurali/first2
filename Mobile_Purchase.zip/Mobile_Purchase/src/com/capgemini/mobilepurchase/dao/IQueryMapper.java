package com.capgemini.mobilepurchase.dao;

public class IQueryMapper {
public static final String INSERT_QUERY="INSERT INTO purchasedetails values(mpsequence.nextval,?,?,?,?,?)";
public static final String GET_PID = "SELECT mpsequence.nextval from DUAL";
public static final String GET_MobileID="select MobileId from mobiles";
public static final String GET_ALLMOBILES="select *from mobiles";

	
}
