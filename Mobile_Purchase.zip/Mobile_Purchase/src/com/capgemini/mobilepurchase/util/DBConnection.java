package com.capgemini.mobilepurchase.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.capgemini.mobilepurchase.exceptions.MobilePurchaseException;

public class DBConnection {

	private static Connection conn = null;
	public static Connection getConnection() throws MobilePurchaseException {
		if(conn==null)
		{
		try{
	
		FileInputStream myfile = new FileInputStream("Resources/Jdbc.properties");
		Properties props = new Properties();
		props.load(myfile);	
		
		String driver = props.getProperty("driver");
		String dbURL = props.getProperty("dbURL");
		String user = props.getProperty("Username");
		String pass = props.getProperty("password");
		Class.forName(driver);
		 conn = DriverManager.getConnection(dbURL,user,pass);
		 
		 
		 
		 
		 
		 
		 conn.commit();
		 }
		catch(FileNotFoundException fe)
		{
			throw new MobilePurchaseException("unable to find Properties file" + fe.getMessage());
		}
		catch(ClassNotFoundException ce)
		{
			throw new MobilePurchaseException("driver class not found" + ce.getMessage());
		}
		catch(IOException ie)
		{
			throw new MobilePurchaseException("problem occured while reading properties" + ie.getMessage());
			
		}
		catch(SQLException se)
		{
			throw new MobilePurchaseException("problem occured while obtaining connect" + se.getMessage());
			
		}
      }
		return conn;
	}
	
}
