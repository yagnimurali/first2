package com.capgemini.mobilepurchase.presentation;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.mobilepurchase.dto.CustomerDetailsDTO;
import com.capgemini.mobilepurchase.exceptions.MobilePurchaseException;
import com.capgemini.mobilepurchase.service.MobilePurchaseServiceImp;

public class MobilePurchaseUI {
	private static Scanner sc;
	static MobilePurchaseServiceImp serv=new MobilePurchaseServiceImp();

	public static void main(String[] args) throws MobilePurchaseException {
		sc = new Scanner(System.in);
		System.out.println("WELCOME TO MOBILE PURCHASE..\n");

		System.out.println("Enter your choice \n");
		System.out.println("1.Purchase details");
		System.out.println("3.Exit");
		System.out.println("2.get all mobile details");

		
		MobilePurchaseUI m = new MobilePurchaseUI();

		String choice = sc.next();
		switch (choice) {
		case "1":
			m.enterdetails();
			break;
		case "2":
			getMobileDetails();
			break;
			
		case "3":
			m.exit();
			break;
		default:
			System.out.println("please enter valid choice");
			System.out.println("1.Purchase details");
			System.out.println("3.Exit");
			int input = sc.nextInt();
			if (input == 1) {
				m.enterdetails();
			} else {
				m.exit();
			}
		}
	}
	public static void getMobileDetails() throws MobilePurchaseException {
		List<CustomerDetailsDTO> mobileList = new ArrayList<CustomerDetailsDTO>();
		mobileList = serv.getAllMobiles();

		if (mobileList != null) {

		Iterator<CustomerDetailsDTO> i = mobileList.iterator();

		while (i.hasNext()) {
			CustomerDetailsDTO obj = (CustomerDetailsDTO) i
		.next();
		System.out.println("MobileId:" + obj.getMobileId());
		System.out.println("Mobile name" + obj.getMobileName());
		System.out.println("MobileQunatity:" + obj.getMobileQuantity());
		System.out.println("MobilePrice" + obj.getMobilePrice());
		System.out.println("------------");
		}
		System.out.println();
		} else {
		System.out.println("there are no mobiles in the stores");
		}
		}



	private void enterdetails() throws MobilePurchaseException {
		String CustomerName;
		String MailId;
		String PhoneNumber;
		String MobileId;
		//String PurchaseId;
		 String MobileName;
		
		 int MobilePrice;
		 int MobileQuantity;
		
		int mid;
		int pid =0;

		MobilePurchaseServiceImp mpi = new MobilePurchaseServiceImp();
		while (true) {
			System.out.println("Enter CustomerName");
			CustomerName = sc.next();
			if (mpi.validateCustomerName(CustomerName) == true) {
				System.out.println("customername is correct");
				break;
			}
		}
		while (true) {
			System.out.println("Enter MailId");
			MailId = sc.next();
			if (mpi.validateMailId(MailId) == true) {
				
				System.out.println("mailId is correct");
				break;
			}
		}
		while (true) {
			System.out.println("Enter PhoneNumber");
			PhoneNumber = sc.next();
			if (mpi.validatePhoneNumber(PhoneNumber) == true) {
				System.out.println("phonenumber is correct");
				break;
			}
		}
		/*while (true) {
			System.out.println("Enter MobileId");
			 MobileId = sc.next();
			if (mpi.validateMobileId(MobileId) == true) {
				mid=Integer.parseInt(MobileId);
				System.out.println("mobileId is correct");
				break;
			}
		}*/
		
		while(true)
		{
			ArrayList<Integer> list=new ArrayList<Integer>();
			list = mpi.getMobId();
			System.out.println("Current Available mobile ids are"+list);
			System.out.println("enter mobileid ");
			MobileId = sc.next();
			 if(mpi.validateMobileId(MobileId)== true)
			 {
				 mid=Integer.parseInt(MobileId);
				 if(list.contains(mid)){
					 break;
					 
				 }else{
					 System.out.println("wrong input choosen please enter correct one");
				 }
			 }else{
				 System.out.println("wrong input choosen");
			 }
			 

			
		}
		/*while (true) {
			System.out.println("Enter PurchaseId");
			 PurchaseId = sc.next();
			if (mpi.validatePurchaseId(PurchaseId) == true) {
				pid = Integer.parseInt(PurchaseId);
				System.out.println("PurchaseId is correct");
				break;
			}
		}*/
		CustomerDetailsDTO cdto = new CustomerDetailsDTO();
		
		
		Date PurchaseDate = new Date();
		System.out.println("------------------\n ENTERED DETAILS \n ---------------");
		cdto.setCustomerName(CustomerName);
		cdto.setMailId(MailId);
		cdto.setPhoneNumber(PhoneNumber);
		cdto.setMobileId(mid);
	//	cdto.setPurchaseId(pid);
		cdto.setPurchaseDate(PurchaseDate);
		
		System.out.println(cdto.getCustomerName());
		System.out.println(cdto.getMailId());
		System.out.println(cdto.getPhoneNumber());
		System.out.println(cdto.getMobileId());
	//	System.out.println(cdto.getPurchaseId());
		System.out.println(cdto.getPurchaseDate());
		cdto = mpi.mobilepur(cdto);
		System.out.println("all details entered sucessfully");
		System.out.println("your puchase id is" + mpi.getpid());
		
		
	}
		//2018 db 2017
/*/try {
	mpd.mobilepur(cdto);
	
	} 
catch (MobilePurchaseException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}
*/
	private void exit() {
		System.out.println("Thank you..!!");
	}

}
