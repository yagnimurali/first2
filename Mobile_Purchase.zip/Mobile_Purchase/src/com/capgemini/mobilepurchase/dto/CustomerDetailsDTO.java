package com.capgemini.mobilepurchase.dto;

import java.time.LocalDate;
import java.util.Date;

public class CustomerDetailsDTO {
	private String CustomerName;
	private String MailId;
	private String PhoneNumber;
	private int MobileId;
	//private int PurchaseId;
	private Date PurchaseDate;
	private String MobileName;
	
	private int MobilePrice;
	private int MobileQuantity;
	
	public Date getPurchaseDate() {
		return PurchaseDate;
	}
	public void setPurchaseDate(Date purchasedate) {
		PurchaseDate = purchasedate;
	}

	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getMailId() {
		return MailId;
	}
	public void setMailId(String mailId) {
		MailId = mailId;
	}
	
	
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public int getMobileId() {
		return MobileId;
	}
	public void setMobileId(int mid) {
		MobileId = mid;
	}
	/*public int getPurchaseId() {
		return PurchaseId;
	}
	public void setPurchaseId(int pid) {
		PurchaseId = pid;
	}
	*/
	public String getMobileName() {
		return MobileName;
	}
	public void setMobileName(String mobileName) {
		MobileName = mobileName;
	}
	public int getMobilePrice() {
		return MobilePrice;
	}
	public void setMobilePrice(int mobilePrice) {
		MobilePrice = mobilePrice;
	}
	public int getMobileQuantity() {
		return MobileQuantity;
	}
	public void setMobileQuantity(int mobileQuantity) {
		MobileQuantity = mobileQuantity;
	}
	

}
